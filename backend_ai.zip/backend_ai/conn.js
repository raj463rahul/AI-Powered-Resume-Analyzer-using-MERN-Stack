const mongoose = require('mongoose');


mongoose.connect('mongodb+srv://adarshsingh7692_db_user:CJt0dQpwWpxKlAGV@cluster0.jtcxyfi.mongodb.net/?appName=Cluster0').then((res)=>{
    console.log("Database Connected Successfully");
}).catch(err=>{
    console.log("Something Error",err);
})