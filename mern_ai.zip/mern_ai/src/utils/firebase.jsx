
import { initializeApp } from "firebase/app";
import { getAuth, GoogleAuthProvider } from "firebase/auth";



const firebaseConfig = {
  apiKey: "AIzaSyDYwYylimO5rTKhIuqx1MEN6gRbxtYqIpI",
  authDomain: "mernai-ec2a1.firebaseapp.com",
  projectId: "mernai-ec2a1",
  storageBucket: "mernai-ec2a1.firebasestorage.app",
  messagingSenderId: "733377291815",
  appId: "1:733377291815:web:a9759974b4362262809002",
  measurementId: "G-C39N1N1X0J"
};

const app = initializeApp(firebaseConfig);

const auth = getAuth(app);
const provider = new GoogleAuthProvider();

export { auth, provider };