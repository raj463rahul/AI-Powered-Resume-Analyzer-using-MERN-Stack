import React from 'react'
import styles from './Admin.module.css';
import { Skeleton } from '@mui/material';
import withAuthHOC from '../../utils/HOC/withAuthHOC'; 

const Admin = () => {
  return (
    <div className={styles.Admin}>
      <div className={styles.AdminBlock}>
        
        <Skeleton 
        variant="rectangular" 
        width={266} height={200}
        sx={{ borderRadius: "20px" }}
        />

        <div className={styles.AdminCard}>
        <h2>CodingHunger</h2>

        <p style={{color: "blue"}}>adarshsingh7692@gmail.com</p>
        <h3>Score : 50% </h3>
        <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Obcaecati id debitis repellendus vero voluptatum rerum praesentium, minima ad voluptatibus laudantium quo, hic veritatis nihil nulla culpa molestias autem, nesciunt neque! Laboriosam enim placeat beatae incidunt tempore inventore nisi sint perferendis obcaecati illum animi, cumque magnam! Mollitia impedit, maiores assumenda reprehenderit nesciunt ab consectetur et quod earum, possimus eius voluptatibus deleniti? Non, reiciendis quia? Quae voluptatem architecto nihil quia autem! Quos animi unde ipsam, tempora voluptatem sit maiores consequatur.</p>
        </div>

        <div className={styles.AdminCard}>
        <h2>CodingHunger</h2>

        <p style={{color: "blue"}}>adarshsingh7692@gmail.com</p>
        <h3>Score : 50% </h3>
        <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Obcaecati id debitis repellendus vero voluptatum rerum praesentium, minima ad voluptatibus laudantium quo, hic veritatis nihil nulla culpa molestias autem, nesciunt neque! Laboriosam enim placeat beatae incidunt tempore inventore nisi sint perferendis obcaecati illum animi, cumque magnam! Mollitia impedit, maiores assumenda reprehenderit nesciunt ab consectetur et quod earum, possimus eius voluptatibus deleniti? Non, reiciendis quia? Quae voluptatem architecto nihil quia autem! Quos animi unde ipsam, tempora voluptatem sit maiores consequatur.</p>
        </div>

        <div className={styles.AdminCard}>
        <h2>CodingHunger</h2>

        <p style={{color: "blue"}}>adarshsingh7692@gmail.com</p>
        <h3>Score : 50% </h3>
        <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Obcaecati id debitis repellendus vero voluptatum rerum praesentium, minima ad voluptatibus laudantium quo, hic veritatis nihil nulla culpa molestias autem, nesciunt neque! Laboriosam enim placeat beatae incidunt tempore inventore nisi sint perferendis obcaecati illum animi, cumque magnam! Mollitia impedit, maiores assumenda reprehenderit nesciunt ab consectetur et quod earum, possimus eius voluptatibus deleniti? Non, reiciendis quia? Quae voluptatem architecto nihil quia autem! Quos animi unde ipsam, tempora voluptatem sit maiores consequatur.</p>
        </div>

        <div className={styles.AdminCard}>
        <h2>CodingHunger</h2>

        <p style={{color: "blue"}}>adarshsingh7692@gmail.com</p>
        <h3>Score : 50% </h3>
        <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Obcaecati id debitis repellendus vero voluptatum rerum praesentium, minima ad voluptatibus laudantium quo, hic veritatis nihil nulla culpa molestias autem, nesciunt neque! Laboriosam enim placeat beatae incidunt tempore inventore nisi sint perferendis obcaecati illum animi, cumque magnam! Mollitia impedit, maiores assumenda reprehenderit nesciunt ab consectetur et quod earum, possimus eius voluptatibus deleniti? Non, reiciendis quia? Quae voluptatem architecto nihil quia autem! Quos animi unde ipsam, tempora voluptatem sit maiores consequatur.</p>
        </div>


      </div>
     
    </div>
  )
}

export default withAuthHOC(Admin);
