import React from 'react'
import styles from './Dashboard.module.css'
import CreditScoreIcon from '@mui/icons-material/CreditScore';
import Skeleton from '@mui/material/Skeleton';
import withAuthHOC from '../../utils/HOC/withAuthHOC';

const Dashboard = () => {
  return (
    <div className={styles.Dashboard}>
      <div className={styles.DashboardLeft}>
        <div className={styles.DashboardHeader}>
            <div className={styles.DashboardHeaderTitle}>Smart Resume  Screening</div>
            <div className={styles.DashboardHeaderLargeTitle}>Resume Match Score</div>
        </div> 
 
        <div className={styles.alertInfo}>
          <div>🔔 Important Instructions:</div>
          <div className={styles.dashboardInstructions}>
            <div>📝Please paste the complete job description in the "Job Description" feild before submitting.</div>
            <div>⚠️ Only PDF format (.pdf) resumes are accepted.</div>
          </div>
        </div>

        <div className={styles.DashboardUploadResume}>
            <div className={styles.DashboardResumeBlock}> 
              Upload Your Resume
            </div>

            <div className={styles.DashboardInputField}>
              <label htmlFor='inputField' className={styles.analyzeAIbtn}>Upload Resume</label>
              <input type='file' accept=".pdf" id='inputField' />
            </div>
        </div>
        <div className={styles.jobDesc}> 
          <textarea className={styles.textArea} placeholder='Paste Your Job Description' rows={10} cols={50} />

          <div className={styles.AnalyzeBtn}>Analyze</div>
        </div> 

        
      </div>

      
            <div className={styles.DashboardRight}>
                <div className={styles.DashboardRightTopCard}>
                    <div>Analyze With AI</div>

                    <img className={styles.profileImg} src={"https://media.licdn.com/dms/image/sync/v2/D5627AQH9Kf73lW9IeA/articleshare-shrink_800/articleshare-shrink_800/0/1741081220379?e=2147483647&v=beta&t=lkxvwBF3NlXb-8FGa71p5nynO7EN1ZcOM6fBqu1DXbQ"} />

                    <h2>Resume Analyzer</h2>
                </div>

                {/* <div className={styles.DashboardRightTopCard}>
                    <div>Result</div>

                    <div style={{display:'flex',justifyContent:'center', alignItems:'center', gap:20}}>
                      <h1>75%</h1>
                      <CreditScoreIcon sx={{fontSize:22}}/>
                    </div>

                <div className={styles.feedback}>
                  <h3>Feedback</h3>
                  <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Architecto ipsa sunt laudantium, nobis omnis nostrum voluptatem aliquam id, labore quaerat placeat sit aut?</p>
                </div>
                </div> */}
                
                 {
                  <Skeleton variant="rectangular" sx={{ borderRadius: "20px" }} width={280} height={280} />
                }
    </div>
    </div>
  )
} 

export default withAuthHOC(Dashboard);
